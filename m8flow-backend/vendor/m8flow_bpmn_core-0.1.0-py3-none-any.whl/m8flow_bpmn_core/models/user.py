from __future__ import annotations

from sqlalchemy import Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from m8flow_bpmn_core.models.base import Base


class UserModel(Base):
    __tablename__ = "user"
    __table_args__ = (
        UniqueConstraint("service", "service_id", name="service_key"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(
        String(255), index=True, nullable=False
    )
    email: Mapped[str | None] = mapped_column(String(255), index=True)
    service: Mapped[str] = mapped_column(String(255), index=True, nullable=False)
    service_id: Mapped[str] = mapped_column(
        String(255), index=True, nullable=False
    )
    display_name: Mapped[str | None] = mapped_column(String(255))
    tenant_specific_field_1: Mapped[str | None] = mapped_column(String(255))
    tenant_specific_field_2: Mapped[str | None] = mapped_column(String(255))
    tenant_specific_field_3: Mapped[str | None] = mapped_column(String(255))
    updated_at_in_seconds: Mapped[int | None] = mapped_column(Integer)
    created_at_in_seconds: Mapped[int | None] = mapped_column(Integer)

    user_group_assignments = relationship(
        "UserGroupAssignmentModel",
        cascade="all, delete-orphan",
        overlaps="groups,users",
    )
    groups = relationship(
        "GroupModel",
        viewonly=True,
        secondary="user_group_assignment",
        overlaps="user_group_assignments,users",
    )
    principal = relationship(
        "PrincipalModel",
        uselist=False,
        cascade="all, delete-orphan",
        overlaps="user",
    )
